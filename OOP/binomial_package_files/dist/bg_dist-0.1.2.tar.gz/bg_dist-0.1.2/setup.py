from setuptools import setup

setup(name='bg_dist',
      version='0.1.2',
      description='Gaussian and Binomial Distributions',
      packages=['bg_dist'],
      author='Pelin Balci',
      zip_safe=False)
